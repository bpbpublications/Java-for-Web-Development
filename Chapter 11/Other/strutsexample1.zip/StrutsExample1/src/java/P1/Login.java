
package P1;

public class Login {
    private String uname;

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }
    public String execute()
    {
    if(uname.equals("admin"))
        return("Success");
    else
        return("Invalid");
    }
    
}
