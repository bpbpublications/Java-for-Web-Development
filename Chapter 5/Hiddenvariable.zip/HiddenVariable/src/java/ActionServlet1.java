import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class ActionServlet1 extends HttpServlet {    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {     
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ActionServlet1</title>");            
            out.println("</head>");
            out.println("<body>");
            String name=request.getParameter("userName");  
            out.print("Welcome "+name);  
            out.print("<form action='second'>");  
            out.print("<input type='hidden' name='uname' value='"+name+"'>");  
            out.print("<input type='submit' value='Next'>");  
            out.print("</form>");       
            out.println("</body>");
            out.println("</html>");
        }}}


