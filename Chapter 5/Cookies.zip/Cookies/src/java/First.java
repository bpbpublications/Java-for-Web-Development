import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class First extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet First</title>");            
            out.println("</head>");
            out.println("<body>");
           String name=request.getParameter("userName");  
            out.print("Welcome "+name+"  in the Cookie Demo");  
            Cookie ck=new Cookie("uname",name);//creating cookie object  
             response.addCookie(ck);//adding cookie in the response  
            out.print("<form action='Second'>");  
             out.print("<input type='submit' value='next'></form>");                            
            out.println("</body>");
            out.println("</html>");}}}

