import javax.servlet.http.HttpServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class NEXT2 extends HttpServlet {   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
        
              response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet NEXT2</title>");            
            out.println("</head>");
            out.println("<body>");
        String n=request.getParameter("name");  
            out.println("<h1>Hello "+n +"</h1>");
            out.println("</body>");
            out.println("</html>");
        } }