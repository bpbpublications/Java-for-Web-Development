import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class URLRewritingExample extends HttpServlet {    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {          
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet URLRewritingExample</title>");            
            out.println("</head>");
            out.println("<body>hello    ");
            String name=request.getParameter("Uname");
            String pwd=request.getParameter("pwd");
             if(name.equals("Sarika") && pwd.equals("vivek"))
             { 
out.println("<h1>"+name+" are successfully login </h1>");
              out.print("<a href='next2?name="+name+"'>visit</a>");
}
            else
                out.println("<h1>User Name or Password is Incorrect </h1>");
            out.println("</body>");
            out.println("</html>");
        }   }}
