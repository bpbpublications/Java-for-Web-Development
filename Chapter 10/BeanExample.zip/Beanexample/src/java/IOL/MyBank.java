//
package IOL;
import java.sql.*;

public class MyBank {
    private String userId,pwd;
    public Connection con;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    public MyBank()throws ClassNotFoundException,SQLException{
   Class.forName("com.mysql.cj.jdbc.Driver");  
con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/MyBank","root","sailboat");  
    }
  public boolean validate() 
   {String ppwd="";
       boolean valid=false;
       try{
           userId=getUserId();
           pwd=getPwd();
           String  strQuery="select * from login where userid='"+userId+"'";
           Statement stat=con.createStatement();
           ResultSet result=stat.executeQuery(strQuery);
           System.out.println(result.next());
           while(result.next())
           {
           ppwd=result.getString(1);
           System.out.println(ppwd);
           }
           ppwd.trim();
           pwd.trim();
           if(ppwd.equals(pwd))
               valid=true;
       }catch(Exception e){}
       return valid;
   }
    
}
