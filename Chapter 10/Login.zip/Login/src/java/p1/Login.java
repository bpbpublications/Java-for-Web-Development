/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;
import com.opensymphony.xwork2.ActionSupport;
/**
 *
 * @author AMIT
 */
public class Login extends ActionSupport{
    private String uname;

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }
    public String execute()
    {
    if(uname.equals("Sarika"))
        return("Success");
    else
        return("Invalid");
    }
    
    
}
